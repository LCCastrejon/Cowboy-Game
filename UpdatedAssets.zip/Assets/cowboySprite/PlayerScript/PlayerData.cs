using UnityEngine;

[CreateAssetMenu(fileName = "PlayerData", menuName = "ScriptableObjects/PlayerData", order = 1)]
public class PlayerData : ScriptableObject
{
    // Movement stats
    public float speed = 5f; // The speed at which the character moves horizontally
    public float acceleration = 10f;
    public float gravityScale = 3f;
    public float fallAcceleration = 2f; // Acceleration due to gravity
    public float airMovementSpeed = 5f;

    // Jumping stats
    public float shortJumpForce = 8f; // Jump force for short taps
    public float longJumpForce = 12f; // Jump force for holding the jump button
    public float maxJumpTime = 0.2f; // Maximum time the jump button can be held

    // Weapon stats
    public int maxAmmo;
    public float reloadTime;
    public float fireRate;
    public int totalClipCount = 26;
}
