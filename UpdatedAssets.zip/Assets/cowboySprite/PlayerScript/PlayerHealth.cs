using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;
public class PlayerHealth : MonoBehaviour
{
    public int maxHealth = 3;
    public int health;
    private Animator anim;
    private Animator deathAnimation;
    private BoxCollider2D boxCollider;
    private Rigidbody2D rb2d;
    private bool isAlive = true; // Flag to track if the player is alive
    public AudioSource playerhurtSound;
    public AudioSource deadMusic;
    public AudioSource backGroundMusic;
    public AudioSource healSound;
    public AudioSource BackGroundAmbientNoise;
    private bool isRestarting = false;
    // Start is called before the first frame update
    void Start()
    {
        health = maxHealth;
        anim = GetComponent<Animator>();
        rb2d = GetComponent<Rigidbody2D>();
        deathAnimation = GetComponentInParent<Animator>();
        boxCollider = GetComponent<BoxCollider2D>(); // Get the BoxCollider2D component

    }

    // Update is called once per frame
    public void TakeDamage(int damage)
    {
        if (!isAlive) return; // If the player is not alive, don't take damage

        health -= damage;
        anim.SetTrigger("Hurt");

        if (health <= 0)
        {
            BackGroundAmbientNoise.Stop();
            backGroundMusic.Stop();
            deadMusic.Play();
            isAlive = false; // Set the player as not alive
            deathAnimation.SetTrigger("Dead");
            // Here you can shrink the collider size
            boxCollider.size = new Vector2(boxCollider.size.x * 0.82f, boxCollider.size.y * 0.82f);

            // Reset Rigidbody2D velocity to stop any existing movement
            rb2d.velocity = Vector2.zero;

            // Restart the scene after a delay, only if the player is not already dead
            if (!isRestarting)
            {
                Restart();
            }
        }
    }

    void Restart()
    {
        isRestarting = true; // Set the flag to true to indicate scene restart is in progress
        StartCoroutine(DelayedRestart(10f)); // Adjust the delay time as needed
    }

    IEnumerator DelayedRestart(float delay)
    {
        yield return new WaitForSeconds(delay);

        Scene currentScene = SceneManager.GetActiveScene();
        SceneManager.LoadScene(currentScene.name);

        isRestarting = false; // Reset the flag after scene reload
    }

    public void Heal(int heal)
    {
        health += heal;
        if (health > maxHealth)
        {
            health = maxHealth;
        }

        // Play the heal sound effect
        if (healSound != null)
        {
            healSound.Play();
        }
    }
    // Add this method to reset the player's state
    public void ResetPlayer()
    {
        isAlive = true;
    }

    // Add this method to check if the player is alive
    public bool IsAlive()
    {
        return isAlive;
    }

    void hurtSound()
    {
        playerhurtSound.Play();
    }
}
