using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyHealth : MonoBehaviour
{
    public int maxHealth;
    public int health;
    private Rigidbody2D rb2d;
    private Animator anim;
    private Animator deathAnimation;
    public AudioSource enemyHurt;
    public AudioSource enemyDead;
    private BoxCollider2D boxCollider;
    public float colliderDeathSize;
    private MeleeEnemy meleeEnemy;
    private bool isDead = false; // Flag to track if the enemy is dead
    // Start is called before the first frame update
    void Start()
    {
        enemyHurt = GetComponent<AudioSource>();
        health = maxHealth;
        anim = GetComponent<Animator>();
        boxCollider = GetComponent<BoxCollider2D>();
        deathAnimation = GetComponent<Animator>();
        rb2d = GetComponent<Rigidbody2D>();
        meleeEnemy = GetComponentInChildren<MeleeEnemy>();

    }

    // Update is called once per frame
    public void TakeDamage(int damage)
    {
        if (isDead) return;
        health -= damage;
        anim.SetTrigger("Hurt");
        if (health <= 0)
        {
            isDead = true;
            anim.SetTrigger("Dead");
            boxCollider.size = new Vector2(boxCollider.size.x * colliderDeathSize, boxCollider.size.y * colliderDeathSize);
        }
    }

        void enemyHurtSound()
        {
            enemyHurt.Play();
        }

        void enemyDeadSound()
        {
            enemyDead.Play();
        }

        void destroyEnemy()
        {
            Destroy(gameObject);
        }

    }
