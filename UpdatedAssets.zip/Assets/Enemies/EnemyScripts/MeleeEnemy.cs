using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class MeleeEnemy : MonoBehaviour
{
    [Header("Attack Parameters")]
    [SerializeField] private float attackCooldown;
    [SerializeField] private float range;
    [SerializeField] private float gizmoHeightMultiplier;
    [SerializeField] private int damage;
    public AudioSource attackSound;

    [Header("Collider Parameters")]
    [SerializeField] private float colliderDistance;
    [SerializeField] private BoxCollider2D boxCollider;

    [Header("Player Layer")]
    [SerializeField] private LayerMask playerLayer;
    private float cooldownTimer = Mathf.Infinity;

    //References
    private Animator anim;
    private PlayerHealth playerHealth;
    private EnemyPatrol enemyPatrol;
    private bool isDead = false;

    private void Awake()
    {
        anim = GetComponent<Animator>();
        enemyPatrol = GetComponentInParent<EnemyPatrol>();
    }


    private void Update()
    {
        if (isDead)
            return;

        cooldownTimer += Time.deltaTime;

        //Attack only when player in sight?
        if (PlayerInSight() && playerHealth.IsAlive())
        {
            if (cooldownTimer >= attackCooldown)
            {
                cooldownTimer = 0;
                anim.SetTrigger("meleeAttack");
            }
        }

        if (enemyPatrol != null)
            enemyPatrol.enabled = !PlayerInSight();
    }

    private bool PlayerInSight()
    {
        RaycastHit2D hit =
            Physics2D.BoxCast(boxCollider.bounds.center + transform.right * range * transform.localScale.x * colliderDistance,
            new Vector3(boxCollider.bounds.size.x * range, boxCollider.bounds.size.y, boxCollider.bounds.size.z),
            0, Vector2.left, 0, playerLayer);

        if (hit.collider != null)
            playerHealth = hit.transform.GetComponent<PlayerHealth>();

        return hit.collider != null;
    }
    private void OnDrawGizmos()
    {
        Gizmos.color = Color.red;
        // Adjust the height component (second parameter) of the Vector3 using the multiplier
        Gizmos.DrawWireCube(boxCollider.bounds.center + transform.right * range * transform.localScale.x * colliderDistance,
            new Vector3(boxCollider.bounds.size.x * range, boxCollider.bounds.size.y * gizmoHeightMultiplier, boxCollider.bounds.size.z));
    }

    private void DamagePlayer()
    {
        if (PlayerInSight() && playerHealth.IsAlive())
            playerHealth.TakeDamage(damage);
    }

    void attackSoundEffect()
    {
        attackSound.Play();
    }

    // Method to disable targeting the player
    public void DisablePlayerTargeting()
    {
        playerLayer = 0; // Set the playerLayer to nothing (no layers)
    }

    // Method to enable targeting the player
    public void EnablePlayerTargeting()
    {
        playerLayer = LayerMask.GetMask("Player"); // Set the playerLayer back to the Player layer
    }

    // Method to disable the enemy's behavior when it dies
    public void DisableEnemy()
    {
        isDead = true;
        // Optionally, you can also stop animations or perform other cleanup tasks here
    }
}