using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyProjectile : MonoBehaviour
{
    [SerializeField] private int damage;
    [SerializeField] private float speed;
    [SerializeField] private float lifetimeDuration; // New variable for projectile lifetime
    private float lifetimeTimer; // Timer to track the projectile's lifetime
    private BoxCollider2D coll;

    private void Awake()
    {
        coll = GetComponent<BoxCollider2D>();
    }

    public void ActivateProjectile()
    {
        lifetimeTimer = 0f; // Reset the lifetime timer when the projectile is activated
        gameObject.SetActive(true);
        coll.enabled = true;
    }

    private void Update()
    {
        float movementSpeed = speed * Time.deltaTime;
        transform.Translate(movementSpeed, 0, 0);

        lifetimeTimer += Time.deltaTime; // Increment the lifetime timer
        if (lifetimeTimer >= lifetimeDuration) // Check if the lifetime duration has been reached
        {
            DestroyProjectile(); // Destroy the projectile
        }
    }

    private void OnTriggerEnter2D(Collider2D collision)
    {
        PlayerHealth playerHealth = collision.GetComponent<PlayerHealth>();
        if (playerHealth != null)
        {
            playerHealth.TakeDamage(damage);
        }
        DestroyProjectile(); // Destroy the projectile when it hits something
    }

    private void DestroyProjectile()
    {
        gameObject.SetActive(false); // Deactivate the projectile
        // Optionally, you can also destroy the game object permanently using Destroy(gameObject)
    }
}