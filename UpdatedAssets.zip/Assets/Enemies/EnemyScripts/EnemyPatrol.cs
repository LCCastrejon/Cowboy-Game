using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class EnemyPatrol : MonoBehaviour
{
    [Header("Patrol Points")]
    [SerializeField] private Transform leftEdge;
    [SerializeField] private Transform rightEdge;

    [Header("Enemy")]
    [SerializeField] private Transform enemy;

    [Header("Movement parameters")]
    [SerializeField] private float speed;
    private Vector3 initScale;
    private bool movingLeft;

    [Header("Idle Behaviour")]
    [SerializeField] private float idleDuration;
    private float idleTimer;

    [Header("Enemy Animator")]
    [SerializeField] private Animator anim;

    [Header("Player Detection")]
    [SerializeField] private LayerMask playerLayer;
    [SerializeField] private float detectionRange;

    private MeleeEnemy meleeEnemy;
    private bool playerDetected;
    private EnemyHealth enemyHealth; // Reference to the EnemyHealth script
    private bool isDead = false; // Flag to track if the enemy is dead

    private void Awake()
    {
        initScale = enemy.localScale;
        meleeEnemy = GetComponentInChildren<MeleeEnemy>();
        enemyHealth = GetComponent<EnemyHealth>(); // Get reference to the EnemyHealth script
    }

    private void Update()
    {
        if (isDead) // If the enemy is dead, stop patrolling
        {
            anim.SetBool("moving", false);
            return;
        }

        if (playerDetected)
        {
            anim.SetBool("moving", false);
            if (meleeEnemy != null)
                meleeEnemy.enabled = true; // Enable the melee enemy script to trigger attack
            return; // Stop patrolling if player is detected
        }

        if (movingLeft)
        {
            if (enemy.position.x >= leftEdge.position.x)
                MoveInDirection(-1);
            else
                DirectionChange();
        }
        else
        {
            if (enemy.position.x <= rightEdge.position.x)
                MoveInDirection(1);
            else
                DirectionChange();
        }
    }

    private void FixedUpdate()
    {
        playerDetected = PlayerInDetectionRange();
    }

    private void DirectionChange()
    {
        anim.SetBool("moving", false);
        idleTimer += Time.deltaTime;

        if (idleTimer > idleDuration)
            movingLeft = !movingLeft;
    }

    private void MoveInDirection(int _direction)
    {
        if (!isDead) // Check if the enemy is not dead before moving
        {
            Debug.Log("Moving enemy.");
            idleTimer = 0;
            anim.SetBool("moving", true);

            // Make enemy face direction
            enemy.localScale = new Vector3(Mathf.Abs(initScale.x) * _direction,
                initScale.y, initScale.z);

            // Move in that direction
            enemy.position = new Vector3(enemy.position.x + Time.deltaTime * _direction * speed,
                enemy.position.y, enemy.position.z);
        }
        else
        {
            Debug.Log("Enemy is dead, should not be moving.");
        }
    }

    private bool PlayerInDetectionRange()
    {
        Collider2D[] hits = Physics2D.OverlapCircleAll(enemy.position, detectionRange, playerLayer);
        foreach (Collider2D hit in hits)
        {
            if (hit.CompareTag("Player"))
            {
                return true;
            }
        }
        return false;
    }

    private void OnDrawGizmosSelected()
    {
        Gizmos.color = Color.yellow;
        Gizmos.DrawWireSphere(enemy.position, detectionRange);
    }

    // Method to disable patrolling when the enemy dies
    public void DisablePatrol()
    {
        isDead = true;
    }
}